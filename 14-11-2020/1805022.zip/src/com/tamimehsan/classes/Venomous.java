package com.tamimehsan.classes;
public interface Venomous {
    boolean isLethalToAdultHumans();
}