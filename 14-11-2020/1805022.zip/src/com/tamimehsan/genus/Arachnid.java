package com.tamimehsan.genus;

import com.tamimehsan.classes.Animal;

public class Arachnid extends Animal {
    public Arachnid(String name, int age) {
        super(name, age);
    }
}
