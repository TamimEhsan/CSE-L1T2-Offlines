package com.tamimehsan.genus;

import com.tamimehsan.classes.Animal;

public class Bird extends Animal {
    public Bird(String name, int age) {
        super(name, age);
    }
}
