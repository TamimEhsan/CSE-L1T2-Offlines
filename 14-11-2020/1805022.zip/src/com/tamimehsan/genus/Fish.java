package com.tamimehsan.genus;

import com.tamimehsan.classes.Animal;

public class Fish extends Animal {
    public Fish(String name, int age) {
        super(name, age);
    }
}
