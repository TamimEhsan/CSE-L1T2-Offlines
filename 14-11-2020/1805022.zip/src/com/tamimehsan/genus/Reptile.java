package com.tamimehsan.genus;

import com.tamimehsan.classes.Animal;

public class Reptile extends Animal {
    public Reptile(String name, int age) {
        super(name, age);
    }
}
