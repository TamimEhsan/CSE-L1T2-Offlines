package com.tamimehsan.species;

import com.tamimehsan.genus.Mammal;

public class FruitBat extends Mammal {
    public FruitBat(String name, int age) {
        super(name, age,true);
    }
}
