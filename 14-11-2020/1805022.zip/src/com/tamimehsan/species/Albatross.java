package com.tamimehsan.species;

import com.tamimehsan.genus.Bird;

public class Albatross extends Bird {
    public Albatross(String name, int age) {
        super(name, age);
    }
}
