package com.tamimehsan.species;

import com.tamimehsan.genus.Fish;

public class GreatWhiteShark extends Fish {
    public GreatWhiteShark(String name, int age) {
        super(name, age);
    }
}
